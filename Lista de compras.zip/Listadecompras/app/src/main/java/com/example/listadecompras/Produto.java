package com.example.listadecompras;

public class Produto{
    String nome;

    double preco;
    boolean checked;


    public Produto(String nome, double preco, boolean checked) {
        this.nome = nome;
        this.preco = preco;
        this.checked = checked;
    }
}
