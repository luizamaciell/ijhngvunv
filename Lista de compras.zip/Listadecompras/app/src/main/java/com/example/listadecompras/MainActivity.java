package com.example.listadecompras;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Produto> produtos;

    Button buttonR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gerarProdutos();

        ListView listView = findViewById(R.id.listView);
        MeuAdaptador adapter = new MeuAdaptador(this, R.layout.item_produto, produtos);
        listView.setAdapter(adapter);



    }
        private void gerarProdutos() {
        produtos = new ArrayList<Produto>();
            criarProduto("Arroz", 4, false);
            criarProduto("Feijão", 3.5, false );
            criarProduto("Frango", 9, false);
            criarProduto("Massa", 5.7, false);
            criarProduto("Farinha", 6.5, false);
            criarProduto("Leite", 6.6, false );
            criarProduto("Pão", 3.9, false);
        }

//instancia o objeto contato e adiciona ao ArrayList<Contato>
        private void criarProduto(String nome, double preco, boolean checked) {
            Produto produto = new Produto(nome,preco, checked);
           produtos.add(produto);
        }
    }
