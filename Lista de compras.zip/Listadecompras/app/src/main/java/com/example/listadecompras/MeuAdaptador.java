package com.example.listadecompras;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class MeuAdaptador extends ArrayAdapter<Produto> {

    LayoutInflater inflater;
    int resourceId;

    public MeuAdaptador(@NonNull Context context, int resource, @NonNull List<Produto> objects) {
        super(context, resource, objects);
        resourceId = resource;
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView = inflater.inflate(resourceId, parent, false);
        CheckBox idCheck = convertView.findViewById(R.id.idCheck);
        Produto produto = getItem(position);
        idCheck.setText( produto.nome + "(" +  produto.preco + ")");

       idCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
               produto.checked = b
           }



        return convertView;
    }
}